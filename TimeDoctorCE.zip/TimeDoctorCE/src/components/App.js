import React from 'react'
import axios from 'axios'

function AuthBtn(props) {
  return (
    <button onClick={props.onClick}>Authenticate</button>
  )
}

function UserName(props) {
  return (
    <p onClick={props.handleUser}>
      {props.uname}
    </p>
  )
}

class App extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      isAuth: false,
      list: [],
      value: '',
      result: false,
      tasks: [],
      access_token: ''
    }
    this.handleChange = this.handleChange.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
    this.handleAuthClick = this.handleAuthClick.bind(this);
    this.handleAuthFalseClick = this.handleAuthFalseClick.bind(this);
    //this.handleUser = this.handleUser.bind(this);
  }
  handleAuthClick() {
    //https://webapi.timedoctor.com/oauth/v2/auth?client_id=<CLIENT_ID>&redirect_uri=REDIRECT_URI&response_type=token- this url will redirect back on successful authentication with the access_token, refresh_token and expiry on the url
    //https://webapi.timedoctor.com/oauth/v2/auth?client_id=769_3m70ph33su0w0c8gs48wgowg84cc484o8kos4wcok4g8cwoc4g&response_type=json&redirect_uri=localhost
    var _this = this
    this.serverRequest =
      axios({
  method:'get',
  url:'https://webapi.timedoctor.com/oauth/v2/auth?client_id=769_3m70ph33su0w0c8gs48wgowg84cc484o8kos4wcok4g8cwoc4g&redirect_uri=localhost&response_type=token-',
  headers: {"Access-Control-Allow-Origin": "*","Content-Type": "application/json","Access-Control-Allow-Methods": "GET,POST"}
})
        //.get('https://webapi.timedoctor.com/oauth/v2/auth?client_id=769_3m70ph33su0w0c8gs48wgowg84cc484o8kos4wcok4g8cwoc4g&redirect_uri=localhost&response_type=token-')
        .then(function (result) {
          console.log(result);
          // chrome.browserAction.onClicked.addListener(function(activeTab){
          //   var newURL = "https://webapi.timedoctor.com/oauth/v2/auth_login";
          //   chrome.tabs.create({ url: newURL });
          // });
          _this.setState({ isAuth: true });
          _this.serverRequest =
            axios
              .get('https://webapi.timedoctor.com/v1.1/companies/552893/users?access_token=ODQ4MGM1YmYxMzRlZTgyY2YxZDJjYjY4ZDQ3OTM0ZmY5ZjMyMjRlYTdlMzRkNjQyMjcwMGEzMzAwNDIwZWIxNA&_format=json')
              .then(function (result) {
                console.log(result);
                _this.setState({
                  list: result.data.users,
                  result: 'data-received'
                })
              })
              .catch(function (error) {
                console.log(error);
                _this.setState({
                  result: 'error'
                })
              });
          // _this.setState({
          //   userDetail: result.data,
          //   list: [],
          //   result: 'data-received'
          // });

        })
        .catch(function (error) {
          console.log(error);
          _this.setState({
            result: 'error'
          })
        });
    return

  }

  handleAuthFalseClick() {
    this.setState({ isAuth: false, value: null, list: [] });
  }

  handleChange(event) {
    this.setState({ value: event.target.value })
  }

  handleUser(userLogin) {
    console.log(userLogin);

    var _this = this
    this.serverRequest =
      axios
        .get('https://webapi.timedoctor.com/v1.1/companies/552893/users/' + userLogin + '/tasks?access_token=ODQ4MGM1YmYxMzRlZTgyY2YxZDJjYjY4ZDQ3OTM0ZmY5ZjMyMjRlYTdlMzRkNjQyMjcwMGEzMzAwNDIwZWIxNA&_format=json')
        .then(function (result) {
          _this.setState({
            tasks: result.data.tasks,
            list: [],
            result: 'data-received'
          });
          console.log(_this.state.userDetail);
        })
        .catch(function (error) {
          console.log(error);
          _this.setState({
            result: 'error'
          })
        });
    return
  }

  //search/users
  handleSubmit(event) {
    event.preventDefault()
    var username = this.state.value
    var _this = this
    this.serverRequest =
      axios
        .get('https://webapi.timedoctor.com/v1.1/companies/552893/users?access_token=ODQ4MGM1YmYxMzRlZTgyY2YxZDJjYjY4ZDQ3OTM0ZmY5ZjMyMjRlYTdlMzRkNjQyMjcwMGEzMzAwNDIwZWIxNA&_format=json')
        .then(function (result) {
          console.log(result);
          _this.setState({
            list: result.data.users,
            result: 'data-received'
          })
        })
        .catch(function (error) {
          console.log(error);
          _this.setState({
            result: 'error'
          })
        });
    return
  }


  render() {

    const isAuth = this.state.isAuth;
    const hasResult = this.state.result;
    let content = null;
    let response = null;
    let userDetails = null;

    if (hasResult == 'data-received') {
      response = <h2>User List:</h2>;
    }
    if (hasResult == 'error') {
      response = <h2>No user found</h2>;
    }

    if (isAuth) {
      content = <div></div>;
    } else {
      content = <AuthBtn onClick={this.handleAuthClick} />;
    }

    /*userDetails = <div>
      {this.state.userDetail.name}<br />
      {this.state.userDetail.login}<br />
      {this.state.userDetail.public_repos}<br />
      {this.state.userDetail.bio}<br />
    </div>;*/

    return (
      <div>
        {content}
        {response}
        {this.state.list.map(function (user) {
          return (
            <div key={user.user_id} className='repo' onClick={this.handleUser.bind(this, user.user_id)}>
              {user.full_name}
            </div>
          )
        }.bind(this))
        }
        {
          this.state.tasks.map(function (task) {
            return (
              <div key={task.task_id} className='repo'>
                {task.task_name}
              </div>
            )
          })
        }

      </div>
    )
  }
}

export default App