# react-start
GitHub user search using React with Webpack and GitHub API

## Requirements

  * [Node.js](http://nodejs.org)

## Quickstart

  * Clone the repository

  * Install the Node modules required for development
```bash
npm install
```
  * Start Webpack
```bash
npm start
```
